using AFH.Booking.Application.Abstractions.Clients;
using AFH.Booking.Function.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;

namespace AFH.Booking.Function.Functions.V1.Bookings;

[BookingOpenApiTag("Clients")]
public sealed class ListDuplicateClientCasesFunction
{
    private readonly IDuplicateClientService _duplicates;

    public ListDuplicateClientCasesFunction(IDuplicateClientService duplicates)
    {
        _duplicates = duplicates;
    }

    [Function("Clients_ListDuplicateCases")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "v1/clients/duplicates/cases/pending")]
        HttpRequestData req,
        CancellationToken ct)
    {
        var response = await _duplicates.ListPendingAsync(ct);
        var contractResponse = response.Select(x => x.ToContract()).ToList();
        return await req.OkJsonAsync(contractResponse, ct, HttpResponseExtensions.SinglePage(contractResponse.Count));
    }
}
