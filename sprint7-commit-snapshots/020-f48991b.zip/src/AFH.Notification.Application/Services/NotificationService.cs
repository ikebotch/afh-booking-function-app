using AFH.Notification.Application.Abstractions;
using AFH.Notification.Application.Models;
using AFH.Notification.Contract.Abstractions;
using AFH.Notification.Contract.V1.Dtos;
using AFH.Notification.Contract.V1.Requests;
using Microsoft.Extensions.Logging;

namespace AFH.Notification.Application.Services;

public sealed class NotificationService : INotificationService, INotificationPublisher
{
    private readonly INotificationAuditStore _auditStore;
    private readonly INotificationRecipientResolver _recipientResolver;
    private readonly INotificationTemplateRenderer _templateRenderer;
    private readonly IContactCentreRoutingResolver _contactCentreResolver;
    private readonly IReadOnlyList<INotificationDeliveryGateway> _deliveryGateways;
    private readonly ILogger<NotificationService> _logger;

    public NotificationService(
        INotificationAuditStore auditStore,
        INotificationRecipientResolver recipientResolver,
        INotificationTemplateRenderer templateRenderer,
        IContactCentreRoutingResolver contactCentreResolver,
        IEnumerable<INotificationDeliveryGateway> deliveryGateways,
        ILogger<NotificationService> logger)
    {
        _auditStore = auditStore;
        _recipientResolver = recipientResolver;
        _templateRenderer = templateRenderer;
        _contactCentreResolver = contactCentreResolver;
        _deliveryGateways = deliveryGateways.ToArray();
        _logger = logger;
    }

    public async Task PublishAsync(NotificationRequested notification, CancellationToken ct)
    {
        var route = await _recipientResolver.ResolveAsync(notification, ct);
        var rendered = await _templateRenderer.RenderAsync(notification, ct);
        await _auditStore.RecordRequestedAsync(notification, ct);

        foreach (var content in rendered.ChannelContent)
        {
            var gateways = _deliveryGateways
                .Where(gateway => gateway.CanSend(content.Channel))
                .ToArray();

            if (gateways.Length == 0)
            {
                _logger.LogWarning(
                    "No notification delivery gateway registered. Type={NotificationType} CorrelationId={CorrelationId} Channel={NotificationChannel}",
                    notification.Type,
                    notification.CorrelationId,
                    content.Channel);
                continue;
            }

            var activeRecipients = route.Recipients.Where(x => x.PreferredChannels?.Contains(content.Channel) == true).ToList();
            
            if (route.CopyContactCentre)
            {
                var ccTarget = _contactCentreResolver.GetContactCentreEmailAddress();
                if (content.Channel == NotificationChannel.Email)
                {
                    if (string.IsNullOrWhiteSpace(ccTarget))
                    {
                        _logger.LogWarning("Contact centre copy skipped: ContactCentreEmailAddress is missing or blank.");
                    }
                    else if (!activeRecipients.Any(r => string.Equals(r.Email, ccTarget, StringComparison.OrdinalIgnoreCase)))
                    {
                        activeRecipients.Add(new NotificationRecipient("ContactCentre", "Contact Centre", ccTarget, null, null, [content.Channel]));
                    }
                }
            }

            foreach (var recipient in activeRecipients)
            {
                var request = new NotificationDeliveryRequest(
                    notification.CorrelationId,
                    content.Channel,
                    recipient,
                    content.Subject,
                    content.HtmlBody,
                    content.TextBody,
                    new Dictionary<string, string>
                    {
                        ["sourceSystem"] = notification.SourceSystem,
                        ["notificationType"] = notification.Type.Name,
                        ["actorType"] = notification.Actor.ActorType,
                        ["actorSourceApplication"] = notification.Actor.SourceApplication
                    });

                foreach (var gateway in gateways)
                    await gateway.SendAsync(request, ct);
            }
        }

        _logger.LogInformation(
            "Notification request recorded. Type={NotificationType} CorrelationId={CorrelationId} RecipientCount={RecipientCount} CopyContactCentre={CopyContactCentre}",
            notification.Type,
            notification.CorrelationId,
            route.Recipients.Count,
            route.CopyContactCentre);
    }
}
